package edu.oop.guild.factory;

import edu.oop.guild.creature.CloudDragon;
import edu.oop.guild.creature.Creature;
import edu.oop.guild.seal.PackageSeal;
import edu.oop.guild.seal.SkyRibbonSeal;

/**
 * Factory for creating sky realm delivery objects.
 */
public class SkyRealmFactory implements RealmFactory {

    /**
     * Creates the courier used for sky deliveries.
     */
    public Creature createCourier() {
        return new CloudDragon();
    }

    /**
     * Creates the seal used for sky packages.
     */
    public PackageSeal createSeal() {
        return new SkyRibbonSeal();
    }
}