package edu.oop.guild.strategy;



//this is the expressDelivery class inheriting abstract class;
//formula: baseFee is 3 coins
//every Kg of package is 1 coins
//9 coins per distanceLeague
//if fragile, adding 10 more points. When delivered in rush, as it may break things.
public class ExpressDeliveryStrategy extends AbstractDeliveryCostStrategy {
    @Override protected int baseFee()          { return 3; }
    @Override protected int weightRate()       { return 1; }
    @Override protected int distanceRate()     { return 9; }
    @Override protected int fragileSurcharge() { return 10; }
}