

package edu.oop.guild.strategy;

import edu.oop.guild.model.DeliveryRequest;

public abstract class AbstractDeliveryCostStrategy implements DeliveryCostStrategy {

    @Override
    public final int estimateCoins(DeliveryRequest request) {
        if (request == null) {
            throw new NullPointerException();
        }
      //every delivery strategy is calculated differently, but they share common formula:
    	//baseFee  +    weightRate* kg  +    distanceRate* distanceLeague    + fragileRate[yes or no]
    	//so in simple terms, there is always a base fee and depending on the strategy additional weight is calculated differently, 
    	//additional distanceLeague is calculated differently and some strategies charge for fragile package.
        int total = baseFee();
        total += request.getWeightKg() * weightRate();
        total += request.getDistanceLeagues() * distanceRate();
        total += request.getPackageType().surchargeCoins();

        if (request.isFragile()) {
            total += fragileSurcharge();
        }

        return total;
    }

    protected abstract int baseFee();

    protected abstract int weightRate();

    protected abstract int distanceRate();

    protected  int fragileSurcharge() {
    	return 0;}
    }
