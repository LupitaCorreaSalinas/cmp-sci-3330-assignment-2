package edu.oop.guild.strategy;


//this is the standardDelivery class inheriting abstract class;
//formula: baseFee is 3 coins
//every Kg of package is 2 coins
// 3 coins per distanceLeague
//if fragile, adding 5 more points.
public class StandardDeliveryStrategy extends AbstractDeliveryCostStrategy {
    @Override protected int baseFee()          { return 3; }
    @Override protected int weightRate()       { return 2; }
    @Override protected int distanceRate()     { return 3; }
    @Override protected int fragileSurcharge() { return 5; }
}