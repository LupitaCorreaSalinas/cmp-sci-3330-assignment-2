
package edu.oop.guild.creature;

import edu.oop.guild.model.DeliveryRequest;
import edu.oop.guild.model.RealmType;
////interface Creature with name, carryingCapacityKg and nativeRealm.
public interface Creature {
    String name();
    int carryingCapacityKg();
    RealmType nativeRealm();

    default boolean canCarry(DeliveryRequest request) { //canCarry method that will check if the weight is less than carrying capacity of the creature.
        if (request == null) {
            throw new NullPointerException();
        }

        return request.getWeightKg() <= carryingCapacityKg()
                && request.getDestinationRealm() == nativeRealm();
    }
}