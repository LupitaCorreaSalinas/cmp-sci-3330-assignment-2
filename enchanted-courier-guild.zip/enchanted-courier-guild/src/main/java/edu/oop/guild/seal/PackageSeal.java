package edu.oop.guild.seal;
//interface
public interface PackageSeal {
    String apply(String label);
    int durability();
}
