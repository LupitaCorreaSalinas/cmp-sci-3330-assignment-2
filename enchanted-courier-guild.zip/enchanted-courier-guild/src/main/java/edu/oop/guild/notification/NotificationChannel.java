package edu.oop.guild.notification;
import edu.oop.guild.model.DeliveryPlan;

public interface NotificationChannel {//interface sending notification
    //any notificaiton class must have send method
    String send(DeliveryPlan plan); 
}
