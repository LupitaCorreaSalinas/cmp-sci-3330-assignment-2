package edu.oop.guild.strategy;

import edu.oop.guild.model.DeliveryRequest;
//I am putting an action in this interface and having abstract class as well.
public interface DeliveryCostStrategy {
    int estimateCoins(DeliveryRequest request);
}