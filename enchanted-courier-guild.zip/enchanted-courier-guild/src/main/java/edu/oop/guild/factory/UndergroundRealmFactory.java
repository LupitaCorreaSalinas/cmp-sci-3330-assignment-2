package edu.oop.guild.factory;

import edu.oop.guild.creature.Creature;
import edu.oop.guild.creature.TunnelMole;
import edu.oop.guild.seal.GlowStoneSeal;
import edu.oop.guild.seal.PackageSeal;

/**
 * Factory for creating underground realm delivery objects.
 */
public class UndergroundRealmFactory implements RealmFactory {

    /**
     * Creates the courier used for underground deliveries.
     */
    public Creature createCourier() {
        return new TunnelMole();
    }

    /**
     * Creates the seal used for underground packages.
     */
    public PackageSeal createSeal() {
        return new GlowStoneSeal();
    }
}