
package edu.oop.guild.log;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class GuildLog {
	//this class is for singleton pattern design and has private constructor, single instance

    private static GuildLog instance;
    private final List<String> entries = new ArrayList<>();

    private GuildLog() {}

    public static GuildLog getInstance() { //getter to access from private.
        if (instance == null) {
            instance = new GuildLog();
        }
        return instance;
    }

    public void record(String entry) { //method for recording 
        Objects.requireNonNull(entry);
        entries.add(entry);
    }

    public int size() {
        return entries.size();
    }

    public List<String> entries() {
        return Collections.unmodifiableList(entries);
    }

    public void clear() {
        entries.clear(); //method for clearing
    } 
}
