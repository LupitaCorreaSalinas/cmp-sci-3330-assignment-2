package edu.oop.guild.notification;
import edu.oop.guild.model.DeliveryPlan;

public class OwlScrollNotificationAdapter implements NotificationChannel {//adapter for old owl system
		private final LegacyOwlScroll owlScroll; //store old system

		public OwlScrollNotificationAdapter(LegacyOwlScroll owlScroll) { 
			if (owlScroll == null) {
				throw new NullPointerException();
			}
			this.owlScroll = owlScroll; 
		}

		@Override
		public String send(DeliveryPlan plan) { //sends notification from delivery plan
			if (plan == null) {
				throw new NullPointerException();
			}
			return owlScroll.dispatchScroll(plan.getRequest().getDestinationRealm().displayName(), plan.summary());
		}

	

}
