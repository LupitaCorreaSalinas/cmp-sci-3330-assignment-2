
package edu.oop.guild.service;

import edu.oop.guild.creature.Creature;
import edu.oop.guild.factory.RealmFactory;
import edu.oop.guild.log.GuildLog;
import edu.oop.guild.model.DeliveryPlan;
import edu.oop.guild.model.DeliveryRequest;
import edu.oop.guild.seal.PackageSeal;
import edu.oop.guild.strategy.DeliveryCostStrategy;

public class DeliveryPlanner {
    private final GuildLog log;                     // shared guild log
    private final DeliveryCostStrategy strategy;    // pricing strategy
    private final RealmFactory factory;             // realm factory for courier and seal

    /**
     * Creates a planner using a factory, cost strategy, and log.
     */
    public DeliveryPlanner(RealmFactory factory, DeliveryCostStrategy strategy, GuildLog log) {

        // Make sure required objects are not null.
        if (factory == null || strategy == null || log == null) {
            throw new NullPointerException();
        }

        this.factory = factory;
        this.strategy = strategy;
        this.log = log;
    }

    /**
     * Creates a delivery plan for the given request.
     */
    public DeliveryPlan plan(DeliveryRequest request) {

        // Check if request is null
        if (request == null) {
            throw new NullPointerException();
        }

        // Create the courier from the realm factory.
        Creature courier = factory.createCourier();

        // Stop if the courier cannot carry this request.
        if (!courier.canCarry(request)) {
            throw new IllegalStateException();
        }

        // Calculate the delivery price using the selected strategy.
        int price = strategy.estimateCoins(request);

        // Create the package seal from the realm factory.
        PackageSeal seal = factory.createSeal();

        // Build the basic label before applying the seal.
        String label = request.getPackageType().label()
                + " to "
                + request.getDestinationRealm().displayName();

        // Apply the seal to the label.
        String sealedLabel = seal.apply(label);

        // Create the final delivery plan.
        DeliveryPlan plan = new DeliveryPlan(request, courier, sealedLabel, price);

        // Record the delivery summary in the guild log.
        log.record(plan.summary());

        return plan;
    
}
}
