package edu.oop.guild.notification;

public class LegacyOwlScroll {
    public String dispatchScroll(String recipient, String inscription) {//the adapter will use this class later
        if (recipient == null || recipient.isBlank() || inscription == null || inscription.isBlank()) { //make it not null or blank
            throw new IllegalArgumentException();
        }
        return "Owl scroll sent to " + recipient + ": " + inscription; //send exact message format expected by test
    }

}
