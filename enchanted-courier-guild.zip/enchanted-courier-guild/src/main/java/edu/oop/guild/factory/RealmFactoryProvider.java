package edu.oop.guild.factory;

import edu.oop.guild.model.RealmType;

/**
 * Provides the correct factory based on the destination realm.
 */
public class RealmFactoryProvider {

    /**
     * Returns the matching factory for the given realm type.
     */
    public RealmFactory forRealm(RealmType realmType) {

        // Realm type is required.
        if (realmType == null) {
            throw new NullPointerException();
        }

        // Select the correct factory based on realm.
        return switch (realmType) {
            case SKY -> new SkyRealmFactory();
            case UNDERGROUND -> new UndergroundRealmFactory();
        };
    }
}