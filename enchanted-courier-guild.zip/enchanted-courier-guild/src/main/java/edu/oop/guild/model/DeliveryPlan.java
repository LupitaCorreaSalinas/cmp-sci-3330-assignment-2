package edu.oop.guild.model;

import edu.oop.guild.creature.Creature;

public class DeliveryPlan {
    private final DeliveryRequest request;      // original delivery request
    private final Creature courier;             // creature delivering the package
    private final String sealedLabel;           // final sealed label text
    private final int priceInCoins;             // delivery cost

    /**
     * Constructs a DeliveryPlan with required values.
     * Validates inputs to ensure the plan is valid.
     */
    public DeliveryPlan(DeliveryRequest request, Creature courier, String sealedLabel, int priceInCoins) {

        // Ensure required fields are not null
        if (request == null || courier == null || sealedLabel == null) {
            throw new NullPointerException();
        }

        // Price must be non-negative
        if (priceInCoins < 0) {
            throw new IllegalArgumentException(); 
        }

        this.request = request;
        this.courier = courier;
        this.sealedLabel = sealedLabel;
        this.priceInCoins = priceInCoins;
    }

    /**
     * Returns the delivery request associated with this plan.
     */
    public DeliveryRequest getRequest() {
        return request; 
    }

    /**
     * Returns the courier responsible for delivery.
     */
    public Creature getCourier() {
        return courier; 
    }

    /**
     * Returns the sealed label for the package.
     */
    public String getSealedLabel() {
        return sealedLabel; 
    }

    /**
     * Returns the delivery price in coins.
     */
    public int getPriceInCoins() {
        return priceInCoins;
    }

    /**
     * Returns a readable summary of the delivery plan.
     */
    public String summary() {
        return courier.name() + " delivers " + sealedLabel + " for " + priceInCoins + " coins";
    }
}