package edu.oop.guild.model;

public enum RealmType {
    SKY("Sky Kingdom"),
    UNDERGROUND("Underground Market");

    private final String displayName; // readable realm name

    /**
     * Creates a realm type with a display name.
     */
    RealmType(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Returns the readable realm name.
     */
    public String displayName() {
        return displayName;
    }
}