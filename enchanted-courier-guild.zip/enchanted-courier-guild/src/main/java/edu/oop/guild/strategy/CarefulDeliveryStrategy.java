
package edu.oop.guild.strategy;

// Careful delivery already handles fragile items, so it uses the default fragile surcharge of 0.
public class CarefulDeliveryStrategy extends AbstractDeliveryCostStrategy {
	
    @Override
    protected int baseFee() {
        return 10;
    }

    @Override
    protected int weightRate() {
        return 5;
    }
  //this is the carefulDelivery class inheriting abstract class;
  //formula: baseFee is 10 coins. Extra attention from start.
  //every Kg of package is 5 coins
  //4 coins per distanceLeague
  //if fragile, adding 0  points. Careful already means taking care of fragile.

    @Override
    protected int distanceRate() {
        return 4;
    }
}