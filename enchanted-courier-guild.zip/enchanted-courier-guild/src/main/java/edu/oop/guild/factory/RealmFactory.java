package edu.oop.guild.factory;

import edu.oop.guild.creature.Creature;
import edu.oop.guild.seal.PackageSeal;

/**
 * Factory interface used to create realm-specific objects.
 * Each realm factory creates its own courier and package seal.
 */
public interface RealmFactory {

    /**
     * Creates the courier creature for the realm.
     */
    Creature createCourier();

    /**
     * Creates the package seal for the realm.
     */
    PackageSeal createSeal();
}