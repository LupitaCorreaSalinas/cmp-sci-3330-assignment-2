package edu.oop.guild.model;

public enum PackageType {
    FOOD("Snack crate", 0),
    POTION("Potion case", 5),
    ARTIFACT("Ancient artifact", 17);

    private final String label;          // readable package name
    private final int surchargeCoins;    // extra cost added for this package type

    /**
     * Creates a package type with a display label and surcharge.
     */
    PackageType(String label, int surchargeCoins) {
        this.label = label;
        this.surchargeCoins = surchargeCoins;
    }

    /**
     * Returns the readable label used in delivery messages.
     */
    public String label() {
        return label;
    }

    /**
     * Returns the extra coin cost for this package type.
     */
    public int surchargeCoins() {
        return surchargeCoins;
    }
}