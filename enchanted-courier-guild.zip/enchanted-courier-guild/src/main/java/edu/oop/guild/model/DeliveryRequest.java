package edu.oop.guild.model;

public class DeliveryRequest {
    private final PackageType packageType;        // type of package being delivered
    private final int weightKg;                   // package weight in kilograms
    private final int distanceLeagues;            // delivery distance
    private final RealmType destinationRealm;     // realm where the package is going
    private final boolean fragile;                // true if package needs fragile handling

    /**
     * Creates a delivery request and checks that all values are valid.
     */
    public DeliveryRequest(PackageType packageType, int weightKg, int distanceLeagues,
                           RealmType destinationRealm, boolean fragile) {

        // Package type is required.
        if (packageType == null) {
            throw new NullPointerException();
        }

        // Destination realm is required.
        if (destinationRealm == null) {
            throw new NullPointerException();
        }

        // Weight must be greater than zero.
        if (weightKg <= 0) {
            throw new IllegalArgumentException();
        }

        // Distance must be greater than zero.
        if (distanceLeagues <= 0) {
            throw new IllegalArgumentException();
        }

        this.packageType = packageType;
        this.weightKg = weightKg;
        this.distanceLeagues = distanceLeagues;
        this.destinationRealm = destinationRealm;
        this.fragile = fragile;
    }

    /**
     * Returns the package type.
     */
    public PackageType getPackageType() {
        return packageType;
    }

    /**
     * Returns the package weight.
     */
    public int getWeightKg() {
        return weightKg;
    }

    /**
     * Returns the delivery distance.
     */
    public int getDistanceLeagues() {
        return distanceLeagues;
    }

    /**
     * Returns the destination realm.
     */
    public RealmType getDestinationRealm() {
        return destinationRealm;
    }

    /**
     * Returns whether the package is fragile.
     */
    public boolean isFragile() {
        return fragile;
    }
}