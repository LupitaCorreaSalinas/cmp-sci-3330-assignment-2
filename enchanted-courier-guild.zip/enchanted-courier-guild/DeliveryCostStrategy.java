package edu.oop.guild.strategy;

import edu.oop.guild.model.DeliveryRequest;

public class DeliveryCostStrategy {

	public Integer estimateCoins(DeliveryRequest request) {
		return null;
	}

}
